package com.example.covid_nutritionapp;

public class Data_UserAnswer {

    private String User;

    public Data_UserAnswer() {
    }

    public Data_UserAnswer(String user) {
        User = user;
    }
    public void setUser(String user) {
        User = user;
    }
    public String getUser() {
        return User;
    }

}
